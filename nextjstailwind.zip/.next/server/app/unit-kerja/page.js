(() => {
var exports = {};
exports.id = 386;
exports.ids = [386];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 1090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 8652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 185:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4592);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6301);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7431);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(94);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4437);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6127);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5486);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6404);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2527);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3332);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7902);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3099);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'unit-kerja',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5814)), "D:\\ReactJS\\nextjs-tailwindkit\\app\\unit-kerja\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 729)), "D:\\ReactJS\\nextjs-tailwindkit\\app\\layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["D:\\ReactJS\\nextjs-tailwindkit\\app\\unit-kerja\\page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/unit-kerja/page"
  

/***/ }),

/***/ 4820:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7885));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1186))

/***/ }),

/***/ 4649:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9775, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3100, 23))

/***/ }),

/***/ 1186:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ModalQuota)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6235);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6682);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7547);
/* __next_internal_client_entry_do_not_use__ default auto */ 



function ModalQuota() {
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const cancelButtonRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    function handleClose() {
        setOpen(!open);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                type: "button",
                onClick: handleClose,
                className: "inline-flex items-center align-middle rounded-full bg-cyan-100 ml-2 px-2 py-0 text-[10px] font-semibold text-cyan-900 shadow-xs ring-1 ring-inset ring-cyan-900 hover:bg-cyan-50",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        className: "text-cyan-900 -ml-0.5 mr-0.5 h-4 w-4",
                        "aria-hidden": "true"
                    }),
                    "Info"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__/* .Transition.Root */ .u.Root, {
                show: open,
                as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_4__/* .Dialog */ .V, {
                    as: "div",
                    className: "relative z-10",
                    initialFocus: cancelButtonRef,
                    onClose: handleClose,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__/* .Transition.Child */ .u.Child, {
                            as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0",
                            enterTo: "opacity-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100",
                            leaveTo: "opacity-0",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "fixed inset-0 z-10 overflow-y-auto",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_3__/* .Transition.Child */ .u.Child, {
                                    as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                                    enter: "ease-out duration-300",
                                    enterFrom: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                                    enterTo: "opacity-100 translate-y-0 sm:scale-100",
                                    leave: "ease-in duration-200",
                                    leaveFrom: "opacity-100 translate-y-0 sm:scale-100",
                                    leaveTo: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_4__/* .Dialog.Panel */ .V.Panel, {
                                        className: "relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "sm:flex sm:items-start",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "mx-auto flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-cyan-100 sm:mx-0 sm:h-10 sm:w-10",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                className: "h-6 w-6 text-cyan-600",
                                                                "aria-hidden": "true"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_4__/* .Dialog.Title */ .V.Title, {
                                                                    as: "h3",
                                                                    className: "text-base font-semibold leading-6 text-gray-900",
                                                                    children: "Info Kuota Kandidat"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "mt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "text-sm text-gray-500",
                                                                            children: "Jumlah kandidat pegawai dihitung berdasarkan jumlah pegawai dalam unit kerja dengan ketentuan sebagai berikut:"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "text-sm text-gray-500",
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                                                className: "table-auto border-collapse border border-grey-400",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                                    className: "px-4 py-2",
                                                                                                    children: "Jumlah Pegawai"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                                                    className: "px-4 py-2",
                                                                                                    children: "Jumlah Quota Pegawai (Maksimal)"
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "1 - 100"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "3"
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "101 - 200"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "4"
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "201 - 350"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "5"
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "351 - 500"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "6"
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "501 - 650"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "7"
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "651 - 800"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "8"
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "801 - 1000"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "9"
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "> 1000"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                                        className: "border px-4 py-2 text-center",
                                                                                                        children: "10"
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "button",
                                                    className: "mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto",
                                                    onClick: ()=>setOpen(false),
                                                    ref: cancelButtonRef,
                                                    children: "Tutup"
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 7885:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ PegawaiCard)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/solid/esm/StarIcon.js
var StarIcon = __webpack_require__(2935);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/solid/esm/TrophyIcon.js
var TrophyIcon = __webpack_require__(5810);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/transitions/transition.js + 4 modules
var transition = __webpack_require__(6235);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/dialog/dialog.js + 24 modules
var dialog = __webpack_require__(6682);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/UserCircleIcon.js
var UserCircleIcon = __webpack_require__(2234);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js
var XMarkIcon = __webpack_require__(1966);
;// CONCATENATED MODULE: ./app/unit-kerja/modal_detail_pegawai.tsx





function classNames(...classes) {
    return classes.filter(Boolean).join(" ");
}
function ModalDetailPegawai() {
    const [open, setOpen] = (0,react_.useState)(false);
    function handleClose() {
        setOpen(!open);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "px-3 pb-2 items-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                    type: "button",
                    onClick: handleClose,
                    className: "flex w-full justify-center text-cyan-900  rounded-md border border-solid border-cyan-900 px-3 py-1.5 text-sm font-semibold leading-6 shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-600 hover:text-slate-100 hover:bg-cyan-700",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(UserCircleIcon/* default */.Z, {
                            className: "h-6 w-6 pr-1"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "Detail Pegawai"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Root */.u.Root, {
                show: open,
                as: react_.Fragment,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog */.V, {
                    as: "div",
                    className: "relative z-10",
                    onClose: setOpen,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                            as: react_.Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0",
                            enterTo: "opacity-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100",
                            leaveTo: "opacity-0",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "fixed inset-0 hidden bg-gray-500 bg-opacity-75 transition-opacity md:block"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "fixed inset-0 z-10 overflow-y-auto",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex min-h-full items-stretch justify-center text-center md:items-center md:px-2 lg:px-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                                    as: react_.Fragment,
                                    enter: "ease-out duration-300",
                                    enterFrom: "opacity-0 translate-y-4 md:translate-y-0 md:scale-95",
                                    enterTo: "opacity-100 translate-y-0 md:scale-100",
                                    leave: "ease-in duration-200",
                                    leaveFrom: "opacity-100 translate-y-0 md:scale-100",
                                    leaveTo: "opacity-0 translate-y-4 md:translate-y-0 md:scale-95",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(dialog/* Dialog.Panel */.V.Panel, {
                                        className: "flex w-full transform text-left text-base transition md:my-5 md:max-w-2xl md:px-2 lg:max-w-2xl",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "relative w-full items-center overflow-hidden bg-white px-4 pb-8 pt-14 shadow-2xl sm:px-6 sm:pt-8 md:p-6 lg:p-8",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    type: "button",
                                                    className: "absolute right-4 top-4 text-gray-400 hover:text-gray-500 sm:right-6 sm:top-8 md:right-6 md:top-6 lg:right-8 lg:top-8",
                                                    onClick: ()=>setOpen(false),
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "sr-only",
                                                            children: "Close"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(XMarkIcon/* default */.Z, {
                                                            className: "h-6 w-6 border border-solid border-cyan-900 rounded-lg",
                                                            "aria-hidden": "true"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex w-full pb-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "absolute top-4 mt-0 sm:top-4 md:top-6 lg:top-4",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-red-900 text-lg",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                    children: "DETAIL PEGAWAI"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex w-full sm:mt-7",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "mr-3",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                        src: "/images/1.png",
                                                                        width: 160,
                                                                        height: 160,
                                                                        alt: "No Photo",
                                                                        className: "object-cover min-w-24 min-h-24 mt-1 border border-solid border-x-grey-400 rounded-2xl border-1 shadow-lg "
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "w-full mt-1",
                                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "grid grid-cols-1 gap-y-0",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                className: "flex w-full text-sm font-bold text-gray-900",
                                                                                children: "KUNTA WIBAWA DASANUGRAHA, SKM, MKM"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                className: "flex w-full text-sm text-gray-900",
                                                                                children: "198702112010121004"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                className: "flex w-full text-sm text-gray-900",
                                                                                children: "Penata Tk.I - III/b"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                className: "flex w-full text-sm text-gray-900",
                                                                                children: "Pranata Komputer Ahli Pertama"
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex w-full border-t border-gray-200",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "font-bold my-1 text-cyan-900",
                                                        children: [
                                                            "Penilaian Ber",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                children: "AKHLAK"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "border-t border-gray-100",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "divide-y divide-gray-100",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("strong", {
                                                                                children: [
                                                                                    "Ber\xa0",
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                                                                                        className: "hidden sm:block"
                                                                                    }),
                                                                                    "(Berorientasi Pelayanan)"
                                                                                ]
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "A (Akuntabel)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "K (Kompeten)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "H (Harmonis)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "L (Loyal)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "A (Adaptif)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "K (Kolaboratif)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "flex mt-8 cursor-pointer font-bold items-center py-1 rounded-lg justify-center border border-gray-900 border-solid text-black hover:bg-gray-200",
                                                            onClick: ()=>setOpen(false),
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "",
                                                                children: "TUTUP"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/unit-kerja/pegawai_card.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function PegawaiCard(params) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col shadow-lg rounded-xl border border-dotted border-cyan-900 border-1",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-24 px-2 text-[12px] py-1 rounded-br-md rounded-tl-md bg-cyan-700 text-white font-bold",
                children: [
                    "Kandidat ",
                    params.no
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex w-full items-center justify-center mb-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "relative mt-3 w-32 h-32 border border-solid border-x-grey-400 rounded-2xl border-1 shadow",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: params.gambar,
                        width: 170,
                        height: 170,
                        alt: "No Photo",
                        className: "object-cover w-32 h-32 rounded-2xl"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "font-bold text-center text-sm xs:text-xs",
                children: params.nama
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-center text-xs xs:text-xs",
                children: params.nip
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                className: "my-2 h-px border-t-0 bg-transparent bg-gradient-to-r from-transparent via-neutral-500 to-transparent opacity-25 dark:opacity-100"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex w-full items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "inline-flex items-center mt-2 mr-2 mb-4 px-2 py-1 bg-green-200 hover:bg-green-300 rounded-full text-xs font-semibold text-green-600",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(StarIcon/* default */.Z, {
                                className: "text-green h-4 w-4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "ml-0 text-green text-xs",
                                children: params.star
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "inline-flex items-center mt-2 mb-4 px-2 py-1 bg-blue-200 hover:bg-blue-300 rounded-full text-xs font-semibold text-blue-600",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(TrophyIcon/* default */.Z, {
                                className: "text-blue h-4 w-4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "ml-1 text-blue text-xs",
                                children: "0"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ModalDetailPegawai, {})
        ]
    });
}


/***/ }),

/***/ 5814:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Page),
  "metadata": () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/20/solid/esm/PlayCircleIcon.js
var PlayCircleIcon = __webpack_require__(2112);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/20/solid/esm/CalendarIcon.js
var CalendarIcon = __webpack_require__(6476);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/20/solid/esm/UsersIcon.js
var UsersIcon = __webpack_require__(6833);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1313);
;// CONCATENATED MODULE: ./app/unit-kerja/pegawai_card.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`D:\ReactJS\nextjs-tailwindkit\app\unit-kerja\pegawai_card.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const pegawai_card = (__default__);
;// CONCATENATED MODULE: ./app/unit-kerja/modal_quota.tsx

const modal_quota_proxy = (0,module_proxy.createProxy)(String.raw`D:\ReactJS\nextjs-tailwindkit\app\unit-kerja\modal_quota.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: modal_quota_esModule, $$typeof: modal_quota_$$typeof } = modal_quota_proxy;
const modal_quota_default_ = modal_quota_proxy.default;


/* harmony default export */ const modal_quota = (modal_quota_default_);
;// CONCATENATED MODULE: ./app/unit-kerja/badge_uker.tsx

function BadgeUker() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-blue-100 border-l-4 mb-4 rounded-lg border-blue-500 rounded-b text-blue-900 px-4 py-3 shadow-md",
        role: "alert",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "hidden py-1 sm:block",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        className: "fill-current h-6 w-6 text-blue-500 mr-4",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 20 20",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M2.93 17.07A10 10 0 1 1 17.07 2.93 10 10 0 0 1 2.93 17.07zm12.73-1.41A8 8 0 1 0 4.34 4.34a8 8 0 0 0 11.32 11.32zM9 11V9h2v6H9v-4zm0-6h2v2H9V5z"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-bold",
                            children: "Informasi"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: "text-sm",
                            children: [
                                "Silahkan pilih ",
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-red-400 font-bold",
                                    children: "1 (satu)"
                                }),
                                " pegawai ",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "Kandidat Hero of The Month Tingkat Unit Kerja"
                                }),
                                " yang telah diurutkan berdasarkan vote terbanyak dari pegawai di tingkat Unit Kerja"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: "text-sm",
                            children: [
                                "Batas pemilihan adalah tanggal\xa0",
                                /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                    children: "20 September 2023"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./app/unit-kerja/page.tsx





const metadata = {
    title: ".: Pemilihan Unit Kerja | Penghargaan Bhakti Karya Husada :.",
    description: "Aplikasi Penghargaan Bhakti Karya Husada",
    developer: "sgt.wibowo@gmail.com",
    icons: "/images/favicon.png"
};
function Page() {
    function BelumWaktunya() {
        alert("Belum Waktunya !");
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(BadgeUker, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "border-dotted rounded-lg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "lg:flex lg:items-center lg:justify-between",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "min-w-0 flex-1",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "text-2xl font-bold leading-7 text-teal-800 sm:truncate sm:text-2xl sm:tracking-tight",
                                    children: "Hero of The Month"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mt-1 flex flex-col sm:mt-0 sm:flex-row sm:flex-wrap sm:space-x-6",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "mt-2 flex items-center text-sm text-bold text-lime-500",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(PlayCircleIcon/* default */.Z, {
                                                    className: "mr-1.5 h-5 w-5 flex-shrink-0 text-lime-400",
                                                    "aria-hidden": "true"
                                                }),
                                                "Tahapan Pemilihan Tingkat Unit Kerja (Dibuka)"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "mt-2 flex items-center text-sm text-bold text-red-500",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(CalendarIcon/* default */.Z, {
                                                    className: "mr-1.5 h-5 w-5 flex-shrink-0 text-red-400",
                                                    "aria-hidden": "true"
                                                }),
                                                "Periode Juli - September 2023"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "mt-2 flex items-center text-sm text-bold text-grey-500",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(UsersIcon/* default */.Z, {
                                                    className: "mr-1.5 h-5 w-5 flex-shrink-0 text-grey-400",
                                                    "aria-hidden": "true"
                                                }),
                                                "Kuota:\xa0",
                                                /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                    children: "3 pegawai"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(modal_quota, {})
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid grid-auto-fit-lg gap-4 py-5 -z-100 mt-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(pegawai_card, {
                                nama: "Cristiano Ronaldo",
                                nip: "198702112010121004",
                                no: 1,
                                star: 210,
                                gambar: "https://assets.goal.com/v3/assets/bltcc7a7ffd2fbf71f5/blt4f833245971cb326/63a46e8e1aef5b627a47ae3c/ronaldoalnassrmarca.jpg?auto=webp&format=pjpg&width=1200&quality=60"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(pegawai_card, {
                                nama: "Sigit Wibowo",
                                nip: "198702112010121004",
                                no: 2,
                                star: 170,
                                gambar: "/images/photo.png"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(pegawai_card, {
                                nama: "Kaivan Akhtar Rafaeyza",
                                nip: "198702112010121004",
                                no: 3,
                                star: 120,
                                gambar: "/images/1.png"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4,682,197,532,967], () => (__webpack_exec__(185)));
module.exports = __webpack_exports__;

})();