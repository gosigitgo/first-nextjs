exports.id = 296;
exports.ids = [296];
exports.modules = {

/***/ 4094:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3326))

/***/ }),

/***/ 3326:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ PegawaiVotePusat)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/solid/esm/StarIcon.js
var StarIcon = __webpack_require__(2935);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/solid/esm/TrophyIcon.js
var TrophyIcon = __webpack_require__(5810);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/transitions/transition.js + 4 modules
var transition = __webpack_require__(6235);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/dialog/dialog.js + 24 modules
var dialog = __webpack_require__(6682);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/UserCircleIcon.js
var UserCircleIcon = __webpack_require__(2234);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js
var XMarkIcon = __webpack_require__(1966);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/CheckCircleIcon.js
var CheckCircleIcon = __webpack_require__(9037);
;// CONCATENATED MODULE: ./app/vote-pusat/modal_pegawai_vote_pusat.tsx





function ModalPegawaiVotePusat() {
    const [open, setOpen] = (0,react_.useState)(false);
    function handleClose() {
        setOpen(!open);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "px-3 pb-2 items-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                    type: "button",
                    onClick: handleClose,
                    className: "flex w-full justify-center text-cyan-900  rounded-md border border-solid border-cyan-900 px-3 py-1.5 text-sm font-semibold leading-6 shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-600 hover:text-slate-100 hover:bg-cyan-700",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(UserCircleIcon/* default */.Z, {
                            className: "font-bold h-6 w-6 pr-1"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "Profil Pegawai"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Root */.u.Root, {
                show: open,
                as: react_.Fragment,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog */.V, {
                    as: "div",
                    className: "relative z-10",
                    onClose: setOpen,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                            as: react_.Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0",
                            enterTo: "opacity-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100",
                            leaveTo: "opacity-0",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "fixed inset-0 hidden bg-gray-500 bg-opacity-75 transition-opacity md:block"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "fixed inset-0 z-10 overflow-y-auto",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex min-h-full items-stretch justify-center text-center md:items-center md:px-2 lg:px-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                                    as: react_.Fragment,
                                    enter: "ease-out duration-300",
                                    enterFrom: "opacity-0 translate-y-4 md:translate-y-0 md:scale-95",
                                    enterTo: "opacity-100 translate-y-0 md:scale-100",
                                    leave: "ease-in duration-200",
                                    leaveFrom: "opacity-100 translate-y-0 md:scale-100",
                                    leaveTo: "opacity-0 translate-y-4 md:translate-y-0 md:scale-95",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(dialog/* Dialog.Panel */.V.Panel, {
                                        className: "flex w-full transform text-left text-base transition md:my-5 md:max-w-2xl md:px-2 lg:max-w-2xl",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "relative w-full items-center overflow-hidden bg-white px-4 pb-8 pt-14 shadow-2xl sm:px-6 sm:pt-8 md:p-6 lg:p-8",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    type: "button",
                                                    className: "absolute right-4 top-4 text-gray-400 hover:text-gray-500 sm:right-6 sm:top-8 md:right-6 md:top-6 lg:right-8 lg:top-8",
                                                    onClick: ()=>setOpen(false),
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "sr-only",
                                                            children: "Close"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(XMarkIcon/* default */.Z, {
                                                            className: "h-6 w-6 border border-solid border-cyan-900 rounded-lg",
                                                            "aria-hidden": "true"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex w-full pb-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "absolute top-4 mt-0 sm:top-4 md:top-6 lg:top-4",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-red-900 text-lg",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                    children: "DETAIL PEGAWAI"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex w-full sm:mt-7",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "mr-3",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                        src: "/images/1.png",
                                                                        width: 160,
                                                                        height: 160,
                                                                        alt: "No Photo",
                                                                        className: "object-cover min-w-24 min-h-24 mt-1 border border-solid border-x-grey-400 rounded-2xl border-1 shadow-lg "
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "w-full mt-1",
                                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "grid grid-cols-1 gap-y-0",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                className: "flex w-full text-sm font-bold text-gray-900",
                                                                                children: "KUNTA WIBAWA DASANUGRAHA, SKM, MKM"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                className: "flex w-full text-sm text-gray-900",
                                                                                children: "198702112010121004"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                className: "flex w-full text-sm text-gray-900",
                                                                                children: "Penata Tk.I - III/b"
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                                className: "flex w-full text-sm text-gray-900",
                                                                                children: "Pranata Komputer Ahli Pertama"
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex w-full border-t border-gray-200",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "font-bold my-1 text-cyan-900",
                                                        children: [
                                                            "Penilaian Ber",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                children: "AKHLAK"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "border-t border-gray-100",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "divide-y divide-gray-100",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("strong", {
                                                                                children: [
                                                                                    "Ber\xa0",
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                                                                                        className: "hidden sm:block"
                                                                                    }),
                                                                                    "(Berorientasi Pelayanan)"
                                                                                ]
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "A (Akuntabel)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "K (Kompeten)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "H (Harmonis)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "L (Loyal)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "A (Adaptif)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "sm:grid sm:grid-cols-3 mb-3 pt-2",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                                                                children: "K (Kolaboratif)"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "w-full align-top text-justify mt-1 text-sm leading-4 text-gray-700 sm:col-span-2 sm:mt-0",
                                                                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam unde repellat odit placeat. Quos est in libero porro magni ducimus, fugit, quo omnis officia temporibus atque laborum. Ipsum, temporibus nesciunt?"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "flex mt-8 cursor-pointer bg-indigo-600 text-white items-center py-2 rounded-lg justify-center border border-gray-900 border-solid hover:bg-indigo-700",
                                                            onClick: ()=>setOpen(false),
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(CheckCircleIcon/* default */.Z, {
                                                                    className: "font-bold h-6 w-6 pr-1"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "",
                                                                    children: "VOTE"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/vote-pusat/pegawai_vote_pusat.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function PegawaiVotePusat(params) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col shadow-lg rounded-xl border border-dotted border-cyan-900 border-1",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-24 px-2 text-[12px] py-1 rounded-br-lg rounded-tl-lg bg-[#CCE70B] text-cyan-900 font-bold",
                children: [
                    "HoTM ",
                    params.no
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex w-full items-center justify-center mb-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "-z-10 relative mt-3 w-32 h-32 border border-solid border-x-grey-400 rounded-2xl border-1 shadow",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: params.gambar,
                        width: 170,
                        height: 170,
                        alt: "No Photo",
                        className: "object-cover w-32 h-32 rounded-2xl"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "font-bold text-center text-sm xs:text-xs",
                children: params.nama
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-center text-xs xs:text-xs",
                children: params.nip
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-center text-xs truncate xs:text-sm h-4 px-2",
                children: params.uker
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                className: "my-2 h-px border-t-0 bg-transparent bg-gradient-to-r from-transparent via-neutral-500 to-transparent opacity-25 dark:opacity-100"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex w-full items-center justify-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "inline-flex items-center mt-2 mr-2 mb-4 px-2 py-1 bg-green-200 hover:bg-green-300 rounded-full text-xs font-semibold text-green-600",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(StarIcon/* default */.Z, {
                                className: "text-green h-4 w-4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "ml-0 text-green text-xs",
                                children: "17"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "inline-flex items-center mt-2 mb-4 px-2 py-1 bg-blue-200 hover:bg-blue-300 rounded-full text-xs font-semibold text-blue-600",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(TrophyIcon/* default */.Z, {
                                className: "text-blue h-4 w-4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "ml-1 text-blue text-xs",
                                children: "1"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ModalPegawaiVotePusat, {})
        ]
    });
}


/***/ }),

/***/ 6929:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\ReactJS\nextjs-tailwindkit\app\vote-pusat\pegawai_vote_pusat.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;