exports.id = 967;
exports.ids = [967];
exports.modules = {

/***/ 1384:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8002))

/***/ }),

/***/ 8002:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  "metadata": () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\layout.tsx","import":"Roboto","arguments":[{"weight":"400","subsets":["latin"],"display":"swap"}],"variableName":"roboto"}
var target_path_app_layout_tsx_import_Roboto_arguments_weight_400_subsets_latin_display_swap_variableName_roboto_ = __webpack_require__(8043);
var target_path_app_layout_tsx_import_Roboto_arguments_weight_400_subsets_latin_display_swap_variableName_roboto_default = /*#__PURE__*/__webpack_require__.n(target_path_app_layout_tsx_import_Roboto_arguments_weight_400_subsets_latin_display_swap_variableName_roboto_);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(1338);
// EXTERNAL MODULE: ./node_modules/nextjs-toploader/dist/index.js
var dist = __webpack_require__(8737);
var dist_default = /*#__PURE__*/__webpack_require__.n(dist);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/disclosure/disclosure.js + 1 modules
var disclosure = __webpack_require__(4702);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/menu/menu.js + 5 modules
var menu = __webpack_require__(4845);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/transitions/transition.js + 4 modules
var transition = __webpack_require__(6235);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js
var XMarkIcon = __webpack_require__(1966);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/Bars3Icon.js
var Bars3Icon = __webpack_require__(4832);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(9483);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./app/components/header.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const header_navigation = [
    {
        key: 1,
        name: "Pemilihan Unit Kerja",
        href: "/unit-kerja",
        targetSegment: "unit-kerja"
    },
    {
        key: 2,
        name: "Vote Unit Kerja",
        href: "/vote-unit-kerja",
        targetSegment: "vote-unit-kerja"
    },
    {
        key: 3,
        name: "Vote Kementerian",
        href: "/vote-pusat",
        targetSegment: "vote-pusat"
    },
    {
        key: 4,
        name: "Pemilihan Akhir",
        href: "/pleno",
        targetSegment: "pleno"
    },
    {
        key: 5,
        name: "Vote Pegawai",
        href: "/vote-pegawai",
        targetSegment: "vote-pegawai"
    }
];
function classNames(...classes) {
    const ret = classes.filter(Boolean).join(" ");
    return ret;
}
function Header() {
    const activeSegment = (0,navigation.useSelectedLayoutSegment)();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "min-h-full sticky top-0 right-0 left-0 z-10",
        children: /*#__PURE__*/ jsx_runtime_.jsx(disclosure/* Disclosure */.p, {
            as: "nav",
            className: "top-0 bg-[#07A9A2]",
            children: ({ open  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mx-auto max-w-7xl px-2 sm:px-6 lg:px-8",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "relative flex h-16 items-center justify-between",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "absolute inset-y-0 left-0 flex items-center sm:hidden",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(disclosure/* Disclosure.Button */.p.Button, {
                                            className: "inline-flex items-center justify-center rounded-md p-2 text-white hover:bg-white hover:text-[#07A9A2] focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#07A9A2]",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "sr-only",
                                                    children: "Open main menu"
                                                }),
                                                open ? /*#__PURE__*/ jsx_runtime_.jsx(XMarkIcon/* default */.Z, {
                                                    className: "block h-6 w-6",
                                                    "aria-hidden": "true"
                                                }) : /*#__PURE__*/ jsx_runtime_.jsx(Bars3Icon/* default */.Z, {
                                                    className: "block h-6 w-6",
                                                    "aria-hidden": "true"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex flex-1 items-center justify-center sm:items-stretch sm:justify-start",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-shrink-0 items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            className: "block h-9 w-auto lg:hidden",
                                                            src: "./images/kemkes3.png",
                                                            alt: "Kemenkes RI"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            className: "hidden h-9 w-auto lg:block",
                                                            src: "./images/kemkes3.png",
                                                            alt: "Kemenkes"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "hidden sm:ml-6 sm:block",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex space-x-2",
                                                    children: header_navigation.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: item.href,
                                                            className: classNames(activeSegment == item.targetSegment ? "bg-[#018294] text-white" : "text-gray-300 hover:bg-[#018294] hover:text-white", "rounded-md px-3 py-2 text-sm font-medium"),
                                                            children: item.name
                                                        }, item.key))
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "absolute inset-y-0 right-0 flex items-center pr-2 sm:static sm:inset-auto sm:ml-6 sm:pr-0",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(menu/* Menu */.v, {
                                            as: "div",
                                            className: "relative ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(menu/* Menu.Button */.v.Button, {
                                                        className: "flex rounded-full bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "sr-only",
                                                                children: "Open user menu"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                className: "h-8 w-8 rounded-full ring-1 ring-white",
                                                                src: "./images/user.png",
                                                                alt: "User"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition */.u, {
                                                    as: react_.Fragment,
                                                    enter: "transition ease-out duration-100",
                                                    enterFrom: "transform opacity-0 scale-95",
                                                    enterTo: "transform opacity-100 scale-100",
                                                    leave: "transition ease-in duration-75",
                                                    leaveFrom: "transform opacity-100 scale-100",
                                                    leaveTo: "transform opacity-0 scale-95",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(menu/* Menu.Items */.v.Items, {
                                                        className: "absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(menu/* Menu.Item */.v.Item, {
                                                                children: ({ active  })=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                        href: "#",
                                                                        className: classNames(active ? "bg-gray-100" : "", "block px-4 py-2 text-sm text-gray-700"),
                                                                        children: "Your Profile"
                                                                    })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(menu/* Menu.Item */.v.Item, {
                                                                children: ({ active  })=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                        href: "#",
                                                                        className: classNames(active ? "bg-gray-100" : "", "block px-4 py-2 text-sm text-gray-700"),
                                                                        children: "Settings"
                                                                    })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(menu/* Menu.Item */.v.Item, {
                                                                children: ({ active  })=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                        href: "#",
                                                                        className: classNames(active ? "bg-gray-100" : "", "block px-4 py-2 text-sm text-gray-700"),
                                                                        children: "Sign out"
                                                                    })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(disclosure/* Disclosure.Panel */.p.Panel, {
                            className: "sm:hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "space-y-1 px-2 pb-3 pt-2",
                                children: header_navigation.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(disclosure/* Disclosure.Button */.p.Button, {
                                        as: "a",
                                        href: item.href,
                                        className: classNames(activeSegment == item.targetSegment ? "bg-[#018294] text-white" : "text-gray-300 hover:bg-[#018294] hover:text-white", "block rounded-md px-3 py-2 text-base font-medium"),
                                        "aria-current": activeSegment == item.targetSegment ? "page" : undefined,
                                        children: item.name
                                    }, item.key))
                            })
                        })
                    ]
                })
        })
    });
}

;// CONCATENATED MODULE: ./app/components/footer.tsx

function Footer() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex fixed drop-shadow-lg bottom-0 pb-0 w-full text-center justify-center bg-slate-200 border border-solid border-grey-100",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                className: "my-2 h-px border-t-0 bg-transparent bg-gradient-to-r from-transparent via-neutral-500 to-transparent opacity-25 dark:opacity-100"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "py-3 text-xs text-center dark:text-gray-400",
                children: "\xa92023 Design with ❤️ by Timker SI[ASN] Biro OSDM."
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/layout.tsx
/* __next_internal_client_entry_do_not_use__ metadata,default auto */ 






const titles = [
    {
        key: 1,
        name: "Pemilihan di Tingkat Unit Kerja",
        targetSegment: "unit-kerja"
    },
    {
        key: 2,
        name: "Voting Tingkat Unit Kerja",
        targetSegment: "vote-unit-kerja"
    },
    {
        key: 3,
        name: "Voting Tingkat Kementerian",
        targetSegment: "vote-pusat"
    },
    {
        key: 4,
        name: "Penilaian Tingkat Akhir",
        targetSegment: "pleno"
    },
    {
        key: 5,
        name: "Hero of The Month",
        targetSegment: "vote-pegawai"
    }
];
const metadata = {
    title: ".: Penghargaan Bhakti Karya Husada :.",
    description: "Aplikasi Penghargaan Bhakti Karya Husada",
    developer: "sgt.wibowo@gmail.com",
    icons: "/images/favicon.png"
};
function RootLayout({ children  }) {
    const activeSegment = (0,navigation.useSelectedLayoutSegment)();
    console.log(activeSegment);
    const selTitle = titles.filter((title)=>title.targetSegment === activeSegment);
    const pageTitle = selTitle?.length > 0 ? selTitle[0].name : "Penghargaan Bhakti Karya Husada";
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        className: "h-96 scrollbar scrollbar-w-1 scrollbar-thumb-teal-500 scrollbar-track-lime-100 scrollbar-corner-lime-400",
        lang: "id",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
            className: (target_path_app_layout_tsx_import_Roboto_arguments_weight_400_subsets_latin_display_swap_variableName_roboto_default()).className,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((dist_default()), {
                    color: "#CCE70B"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Header, {}),
                /*#__PURE__*/ jsx_runtime_.jsx("header", {
                    className: "bg-slate-100 shadow",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mx-auto max-w-7xl px-3 py-3 sm:px-6 lg:px-8",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "text-2xl font-bold tracking-tight text-teal-800",
                            children: pageTitle
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("main", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mx-auto pb-10 max-w-7xl px-3 py-3 sm:px-6 lg:px-8",
                        children: children
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
            ]
        })
    });
}


/***/ }),

/***/ 729:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "metadata": () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\ReactJS\nextjs-tailwindkit\app\layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["metadata"];


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 1338:
/***/ (() => {



/***/ })

};
;